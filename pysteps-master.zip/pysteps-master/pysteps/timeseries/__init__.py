# -*- coding: utf-8 -*-
"""Methods and models for time series analysis."""
