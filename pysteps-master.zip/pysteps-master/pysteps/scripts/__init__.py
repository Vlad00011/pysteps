# -*- coding: utf-8 -*-
"""
Standalone utility scripts for pysteps (e.g. parameter estimation from the
given data).
"""
