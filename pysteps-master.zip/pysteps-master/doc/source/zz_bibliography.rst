.. _bibliography:

============
Bibliography
============


.. bibliography::
    :all:
