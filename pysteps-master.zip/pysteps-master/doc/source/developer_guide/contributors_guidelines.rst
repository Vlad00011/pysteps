.. _contributor_guidelines:

.. include:: ../../../CONTRIBUTING.rst