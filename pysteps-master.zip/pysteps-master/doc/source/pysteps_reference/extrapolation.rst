=====================
pysteps.extrapolation
=====================

Extrapolation module functions and interfaces.

.. automodule:: pysteps.extrapolation.interface
.. automodule:: pysteps.extrapolation.semilagrangian

