.. automodule:: pysteps.decorators
