===============
pysteps.feature
===============

Implementations of feature detection methods.


.. automodule:: pysteps.feature.interface
.. automodule:: pysteps.feature.blob
.. automodule:: pysteps.feature.tstorm
.. automodule:: pysteps.feature.shitomasi

