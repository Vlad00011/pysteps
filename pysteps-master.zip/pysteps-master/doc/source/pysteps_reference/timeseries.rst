==================
pysteps.timeseries
==================

Methods and models for time series analysis.


.. automodule:: pysteps.timeseries.autoregression
.. automodule:: pysteps.timeseries.correlation

