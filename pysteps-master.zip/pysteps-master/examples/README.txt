.. _example_gallery:

Example gallery
===============

Below is a collection of example scripts and tutorials to illustrate the usage 
of pysteps.

These scripts require the pysteps example data.
See the installation instructions in the :ref:`example_data` section.